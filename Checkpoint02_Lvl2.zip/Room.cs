﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint02
{
    class Room
    {
        public string Name { get; set; }
        public int Area { get; set; }
        public string LightsOnOrOff { get; set; }

    }
}
